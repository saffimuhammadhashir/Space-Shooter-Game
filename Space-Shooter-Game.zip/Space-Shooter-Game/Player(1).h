#pragma once
#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>

#include<cmath>

#include"PlayerFire.cpp"

class Player {
    public: sf::Texture tex;
    sf::Sprite sprite;
    sf::Texture texShield;
    sf::Sprite spriteShield;
    sf::SoundBuffer fireBuffer;
    sf::Sound fireSound;
    float speed = 1;
    int x,
    y,
    xs,
    ys;
    static int firebreak,
    angle;
    int health;
    int lives;
    static int powerups;
    PlayerFire * StartFire = nullptr;
    bool shield = false,
    activateshield = false,
    firepower = false;
    std::string name,
    badge = "";
    int score = 0;
    bool fire7 = false;
    Player();
    Player(std::string png_path);
    void FIRE();
    /*
Fire * current = StartFire;
        while (current != nullptr) {
            current -> update();
            current = current -> LinkFire;
        }
    */

    void addOns();
    void shoot();
    void move(std::string s);
    void update();
    void createFire(float x, float y);
};
int Player::firebreak = 0;
int Player::angle = -90;
int Player::powerups = -1;
