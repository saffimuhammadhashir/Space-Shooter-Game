#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>
#include"Fire.h"

class PlayerFire:public Fire {
    public: 
    float speed = -1;
    PlayerFire * LinkFire = nullptr;
    double pos;
    PlayerFire(int a);
    void activate(sf::Vector2f position) override;
    void update() ;
    void updateEnemy();
    void updatePowerup();

};
