#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>


#include "Enemy.cpp"

#include "Player.cpp"

#include<string>

#include<cstring>

#include"Monster.cpp"

#include"Dragon.cpp"

#include <fstream>

#include"PowerUp.cpp"

using namespace sf;

class Game {
    public: Sprite background,
    background1; //Game background sprite
    Texture bg_texture,
    bg_texture1;
    bool is_game_over = false;
    Player * p; //player 
    sf::SoundBuffer menuBuffer;
    sf::Sound menuSound;
    sf::SoundBuffer PausemenuBuffer;
    sf::Sound PausemenuSound;
    sf::Texture texDamage;
    sf::Sprite spriteDamage;
    Enemy * StartEnemy = NULL;
    int score;
    std::string name;

    int Wavechk;
    int Levelchk;
    bool alpha;
    // Enemy * enemy = nullptr;.
    void display_menu();
    void pause_menu(RenderWindow & old);
    void load_screen();
    int spaceship_selection();
    void start_game();
    void Fire_hit(Enemy * StartEnemy, Player * p, RenderWindow & window);
    void enemy_hit(Enemy * StartEnemy, Player * p, RenderWindow & window);
    void player_hit(Enemy * StartEnemy, Player * p, RenderWindow & window);
    void Monster_hit(Monster & m, Player & p);
    void Dragon_hit(Dragon & m, Player & p);
    void game_over_screen(RenderWindow & window, int score, int level, int wave);
    void displaySprites(Enemy * StartEnemy, Player * p, RenderWindow & window, Monster & m, Dragon & d);
    void getPlayerName(sf::RenderWindow & window);
    void add_score_to_file(int score, Player & p);
    void assignBadges();
    void specialeffects(Monster & m, Dragon & d, PowerUp & Pu, Clock & monster_timer, Clock & dragon_timer, Clock & PowerUp_timer, Player & p);
    void PowerUp_hit(PowerUp & Pu, Player & p, Clock & PowerUp_timer);
    void displayFileContent(const std::string & filename);
    bool chkDamage=false,lifelost=false;
    Game() {

        p = new Player("img/player_ship.png");
        bg_texture.loadFromFile("img/background.jpg");
        background.setTexture(bg_texture);
        background.setScale(2.25, 1.35);
        menuBuffer.loadFromFile("sounds/menu.ogg");
        menuSound.setBuffer(menuBuffer);
        PausemenuBuffer.loadFromFile("sounds/menu.ogg");
        PausemenuSound.setBuffer(PausemenuBuffer);
        texDamage.loadFromFile("img/damage2.png");
        spriteDamage.setTexture(texDamage);
         spriteDamage.setScale(0.75, 0.75);
        menuSound.setLoop(true);
        PausemenuSound.setLoop(true);
        
        
        Wavechk = 1;
        Levelchk = 1;
        alpha = true;
        score = 0;
        // enemy = new Enemy[1000];
        //bg_texture1.loadFromFile("img/start.mp4");
        //background1.setTexture(bg_texture1);
        //background1.setScale(2.25, 1.35);

    }

};
