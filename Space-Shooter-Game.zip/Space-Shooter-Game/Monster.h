#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>

#include "MonsterFire.cpp"

class Monster {
    public: sf::Sprite sprite;
    sf::Texture texture;
    float x;
    float y;
    float speed,
    speed1;
    bool active;
    sf::Clock beam_timer;
    sf::Clock move_timer;
    float beam_interval;
    float move_interval;
    float beam_duration;
    int state;

    MonsterFire * StartFireMonster = NULL;

    Monster();

    void activate();
    void deactivate();
    void newMonster(int a);
    void update(float dt, Player & player);
};
