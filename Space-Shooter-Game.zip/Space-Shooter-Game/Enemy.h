#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>

#include"EnemyFire.cpp"

using namespace sf;

class Enemy {
    public: Texture texture;
    Sprite sprite;
    float speed = 0.1;
    float speed1 = 0.1;
    static int movement_chk;
    bool active = false;
    EnemyFire * StartFireEnemy = NULL;
    Enemy * LinkEnemy = NULL;
    double health;
    int waveEnemy;
    int LevelEnemy;
    int Enemynumber;
    int EnemyId;
    int fireDelay;
    bool chkfire=false;
    Enemy(int level, int Wavechk);
    void activate(Vector2f position);
    void update(Clock & time);
    void createFireEnemy(float x, float y);
};
int Enemy::movement_chk = 0;
