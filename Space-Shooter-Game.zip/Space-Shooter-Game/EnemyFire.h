#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>
#include"Fire.h"

using namespace sf;


class EnemyFire: public Fire {
    public:
    EnemyFire * LinkFireEnemy = NULL;
    EnemyFire(int level);
    void activate(sf::Vector2f position) override;
    void update() ;
};
