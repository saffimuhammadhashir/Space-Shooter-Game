#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>

#include"DragonFire.h"

DragonFire::DragonFire(int state) {
    if (state == 0)
        texture.loadFromFile("img/PNG/Lasers/laserBlue11.png");
    if (state == 1)
        texture.loadFromFile("img/PNG/Lasers/laserGreen01.png");
    if (state == 2)
        texture.loadFromFile("img/PNG/Lasers/laserRed11.png");
    sprite.setTexture(texture);
    sprite.setScale(2, 2);
    firecheck = 0;
}

void DragonFire::activate(Vector2f position) {
    active = true;
    visible = true;
    sprite.setPosition(position);
    FireTime.restart();
}

void DragonFire::update(float time, int direction) {
    if (active) {
        if (FireTime.getElapsedTime().asSeconds() > 0.18) {
            if (direction == 0)
                sprite.move(-19, 12);
            if (direction == 1)
                sprite.move(0, 12);
            if (direction == 2)
                sprite.move(19, 12);
        }
        if (sprite.getPosition().y > 780) {
            active = false;
        }
    }
}
