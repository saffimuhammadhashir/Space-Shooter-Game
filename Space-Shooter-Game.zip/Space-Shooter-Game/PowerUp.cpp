#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>

#include"PowerUp.h"


PowerUp::PowerUp() {

    speed = 0.1;
    speed1 = 200;
    active = false;

}

void PowerUp::activate() {
    active = true;
    sprite.setPosition(x, y);
    int a = -100;
    do {
        a = rand() % 900 + 1;
    } while (!(a > 0 && a < 950));

    x = a;
    y = 0;

}
void PowerUp::deactivate() {
    active = false;

}
void PowerUp::newPowerUp(int a) {
    int b = rand() % 4;
    type = a;
    switch (a) {

    case 0: {
        switch (b) {
        case 0: {
            texture.loadFromFile("img/PNG/Power-ups/powerupBlue.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 1: {
            texture.loadFromFile("img/PNG/Power-ups/powerupGreen.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 2: {
            texture.loadFromFile("img/PNG/Power-ups/powerupRed.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 3: {
            texture.loadFromFile("img/PNG/Power-ups/powerupYellow.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }

        }
        break;
    }

    case 1: {
        switch (b) {
        case 0: {
            texture.loadFromFile("img/PNG/Power-ups/powerupBlue_bolt.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 1: {
            texture.loadFromFile("img/PNG/Power-ups/powerupGreen_bolt.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 2: {
            texture.loadFromFile("img/PNG/Power-ups/powerupRed_bolt.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 3: {
            texture.loadFromFile("img/PNG/Power-ups/powerupYellow_bolt.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }

        }
        break;
    }

    case 2: {
        switch (b) {
        case 0: {
            texture.loadFromFile("img/PNG/Power-ups/powerupBlue_shield.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 1: {
            texture.loadFromFile("img/PNG/Power-ups/powerupGreen_shield.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 2: {
            texture.loadFromFile("img/PNG/Power-ups/powerupRed_shield.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 3: {
            texture.loadFromFile("img/PNG/Power-ups/powerupYellow_shield.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }

        }
        break;
    }

    case 3: {
        switch (b) {
        case 0: {
            texture.loadFromFile("img/PNG/Power-ups/powerupBlue_star.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 1: {
            texture.loadFromFile("img/PNG/Power-ups/powerupGreen_star.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 2: {
            texture.loadFromFile("img/PNG/Power-ups/powerupRed_star.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 3: {
            texture.loadFromFile("img/PNG/Power-ups/powerupYellow_star.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }

        }
        break;
    }

    case 4: {
        switch (b) {
        case 0: {
            texture.loadFromFile("img/PNG/Power-ups/danger1.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 1: {
            texture.loadFromFile("img/PNG/Power-ups/danger2.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 2: {
            texture.loadFromFile("img/PNG/Power-ups/danger3.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }
        case 3: {
            texture.loadFromFile("img/PNG/Power-ups/danger4.png");
            sprite.setTexture(texture);
            sprite.setScale(scale, scale);
            break;
        }

        }
        break;
    }
    }

    state = a;
}

void PowerUp::update(float dt, Player & player) {
    if (!active) {
        return;
    }

    // move left and right
    if ((sprite.getPosition().x < 0 || sprite.getPosition().x > 1000)) {

        speed = -speed;
    }
    if (state % 2 == 0)
        x += speed;
    else
        x -= speed;
    y += 0.1;
    sprite.setPosition(x, y);

}
