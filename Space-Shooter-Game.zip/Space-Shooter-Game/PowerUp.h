#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>


class PowerUp {
    public: sf::Sprite sprite;
    sf::Texture texture;
    float x;
    float y;
    float speed,
    speed1;
    bool active;
    int scale = 2;
    int state;
    int type;

    PowerUp();
    void activate();
    void deactivate();
    void newPowerUp(int a);
    void update(float dt, Player & player);
};
