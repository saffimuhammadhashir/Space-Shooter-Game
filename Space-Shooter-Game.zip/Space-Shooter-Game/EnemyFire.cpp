#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include"EnemyFire.h"

using namespace sf;

EnemyFire::EnemyFire(int level) {
    if (level == 1)
        texture.loadFromFile("img/PNG/Lasers/laserRed02.png");
    if (level == 2)
        texture.loadFromFile("img/PNG/Lasers/laserGreen15.png");
    if (level == 3)
        texture.loadFromFile("img/PNG/Lasers/laserBlue12.png");

    sprite.setTexture(texture);
    sprite.setScale(0.85f, 0.85f);
    firecheck = 0;
}

void EnemyFire::activate(Vector2f position) {
    active = true;
    visible = true;
    sprite.setPosition(position);
}

void EnemyFire::update() {
    if (active) {
        sprite.move(0, 0.3);
        if (sprite.getPosition().y > 780) {
            active = false;
        }
    }
}
