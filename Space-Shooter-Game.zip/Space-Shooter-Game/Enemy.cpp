#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>

#include"Enemy.h"

using namespace sf;

Enemy::Enemy(int level, int Wavechk) {
    if (level >= 4)
        level = rand() % 3 + 1;
    if (level == 1) {
        texture.loadFromFile("img/enemy_1.png");
        sprite.setTexture(texture);
        sprite.setScale(0.5f, 0.5f);
        health = 15000;
        LevelEnemy = level;
        waveEnemy = Wavechk;
        fireDelay = 5;
    }
    if (level == 2) {
        texture.loadFromFile("img/enemy_2.png");
        sprite.setTexture(texture);
        sprite.setScale(0.5f, 0.5f);
        health = 20000;
        LevelEnemy = level;
        waveEnemy = Wavechk;
        fireDelay = 3;
    }
    if (level == 3) {
        texture.loadFromFile("img/enemy_3.png");
        sprite.setTexture(texture);
        sprite.setScale(0.5f, 0.5f);
        health = 30000;
        LevelEnemy = level;
        fireDelay = 2;
        waveEnemy = Wavechk;
    }
    EnemyId = movement_chk;

    movement_chk++;

}

void Enemy::activate(Vector2f position) {
    active = true;
    sprite.setPosition(position);
}

void Enemy::update(Clock & time) {
    if (active) {
        if (EnemyId % 2 == 0)
            sprite.move(-speed * (waveEnemy + 1), 0 + (LevelEnemy + 1) * speed1);
        else
            sprite.move(speed * (waveEnemy + 1) / 2, 0 + (LevelEnemy + 1) * speed1 / 2);
        if (sprite.getPosition().x < 0 || sprite.getPosition().x > 1000) {
            speed = -speed;
        }
        if (sprite.getPosition().y < 0 || sprite.getPosition().y > 550) {
            speed1 = -speed1;
        }
        // Fire bullets randomly
int a=8+rand()%50;
        if (time.getElapsedTime().asSeconds() >= fireDelay && time.getElapsedTime().asSeconds() >= a) {
            EnemyFire * newFire = new EnemyFire(LevelEnemy);
            newFire -> activate(sprite.getPosition() + Vector2f(20, 50));
            newFire -> LinkFireEnemy = StartFireEnemy;
            StartFireEnemy = newFire;
            time.restart();
           
            
        }
    }

    // Update fire sprites
    EnemyFire * current = StartFireEnemy;
    while (current != NULL) {
        current -> update();
        current = current -> LinkFireEnemy;
    }

}

void Enemy::createFireEnemy(float x, float y) {
    EnemyFire * newFire = new EnemyFire(LevelEnemy);
    newFire -> activate(sf::Vector2f(x, y));
    newFire -> LinkFireEnemy = StartFireEnemy;
    StartFireEnemy = newFire;
}
