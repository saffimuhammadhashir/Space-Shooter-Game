#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>

class Fire {
public:
    sf::Texture texture;
    sf::Sprite sprite;
    bool active = false;
    bool visible = false;
    int firecheck;
    virtual void activate(sf::Vector2f position) = 0;
   
};

