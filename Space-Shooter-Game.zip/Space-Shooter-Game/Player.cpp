#pragma once
#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>

#include<cmath>

#include"Player.h"


Player::Player() {
    x = 340;
    y = 700;
    sprite.setPosition(sf::Vector2f(x, y));
    sprite.setScale(0.75, 0.75);
    lives = 3;
    health = 10000;
}

Player::Player(std::string png_path) {
    fireBuffer.loadFromFile("sounds/fire.ogg");
    fireSound.setBuffer(fireBuffer);
    tex.loadFromFile(png_path);
    sprite.setTexture(tex);
    texShield.loadFromFile("img/PNG/Effects/shield3.png");
    spriteShield.setTexture(texShield);

    x = 340;
    y = 700;
    sprite.setPosition(sf::Vector2f(x, y));
    sprite.setScale(0.75, 0.75);
    lives = 3;
    health = 10000;
}

void Player::FIRE() {

    if (fire7) {

        for (int i = 0; i < 7; i++) {

            double alter1[7] = {
                1,
                0.7,
                0.3,
                0,
                -0.3,
                -0.7,
                -1
            }, alter2[7] = {
                50,
                40,
                30,
                20,
                30,
                40,
                50
            };

            PlayerFire * newFire = new PlayerFire(0);
            //  std::cout<<"chk"<<i<<std::endl;
            newFire -> activate(sprite.getPosition() + sf::Vector2f(10.0f, -20.0f + alter2[i]));
            newFire -> pos = alter1[i];
            if (StartFire == nullptr) {
                StartFire = newFire;
            } else {
                PlayerFire * current = StartFire;
                while (current -> LinkFire != nullptr) {
                    current = current -> LinkFire;
                }
                current -> LinkFire = newFire;

            }
            fireSound.play();

        }
    } else {
        PlayerFire * newFire = new PlayerFire(powerups);
        newFire -> activate(sprite.getPosition() + sf::Vector2f(28.0f, -20.0f));
        if (StartFire == nullptr) {
            StartFire = newFire;
        } else {
            PlayerFire * current = StartFire;
            while (current -> LinkFire != nullptr) {
                current = current -> LinkFire;
            }
            current -> LinkFire = newFire;

        }
        fireSound.play();
    }

    /*
Fire * current = StartFire;
        while (current != nullptr) {
            current -> update();
            current = current -> LinkFire;
        }
    */
}

void Player::move(std::string s) {
    float delta_x = 0, delta_y = 0;
    if (s == "l")
        delta_x = -1; //move the player left
    else if (s == "r")
        delta_x = 1; //move the player right
    if (s == "u")
        delta_y = -1;
    else if (s == "d")
        delta_y = 1;

    delta_x *= speed;
    delta_y *= speed;

    float new_x = sprite.getPosition().x + delta_x;
    float new_y = sprite.getPosition().y + delta_y;

    if (new_x < 0) {
        new_x = 0;
    } else if (new_x + sprite.getGlobalBounds().width > 1080) {
        new_x = 1080 - sprite.getGlobalBounds().width;
    }

    if (new_y < 0) {
        new_y = 0;
    } else if (new_y + sprite.getGlobalBounds().height > 780) {
        new_y = 780 - sprite.getGlobalBounds().height;
    }

    sprite.setPosition(sf::Vector2f(new_x, new_y));
    if (shield == true && activateshield == true) {
        xs = sprite.getGlobalBounds().height - 20;
        ys = sprite.getGlobalBounds().width + 10;

        spriteShield.setPosition(sf::Vector2f(new_x - 30, new_y - 25));

    }
}
void Player::shoot() {
    if (!fire7) {
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {
            if (firebreak== 175)
                FIRE();
        }
        if (firebreak == 350) {
            firebreak = 0;
        }
        if (firebreak == 0) {
            FIRE();

        }
    }
    if (fire7 ) {
    
        if (firebreak == 350) {
            firebreak = 0;
        }
        if (firebreak == 0 || firebreak==175) {
            FIRE();

        }

    }

    firebreak++;
}
void Player::addOns() {
    if (powerups == 0) {

        shield = true;
        fire7 = true;
       StartFire = nullptr;
       powerups=-1;
    }

    if (powerups == 1) {
        lives++;
        powerups = -1;

    }

    if (powerups == 2) {
        shield = true;
        activateshield = true;
        powerups = -1;

    }
    if (powerups == 3) {
        firepower = true;
        shield = true;
        StartFire = nullptr;
        powerups=-1;
        
    }

    if (powerups == 4) {
        lives--;
        powerups = -1;

    }
}

void Player::update() {
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
        move("l");
    } else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
        move("r");
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
        move("u");
    } else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
        move("d");
    }

    PlayerFire * current = StartFire;
    while (current != nullptr) {
        if (!fire7)
            current -> update();
        if (fire7)
            current -> updatePowerup();
        current = current -> LinkFire;
    }

    shoot();
    addOns();

}
void Player::createFire(float x, float y) {
    PlayerFire * newFire = new PlayerFire(powerups);
    newFire -> activate(sf::Vector2f(x, y));
    newFire -> LinkFire = StartFire;
    StartFire = newFire;

}
