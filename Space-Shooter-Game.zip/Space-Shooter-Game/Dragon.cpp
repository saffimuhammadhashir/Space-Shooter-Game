#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>

#include "DragonFire.cpp"

#include "Dragon.h"


Dragon::Dragon() {
    //  if(a%2==0)
    texture.loadFromFile("img/dragon1.png");
    //else
    // texture.loadFromFile("img/Dragon.png");
    sprite.setTexture(texture);
    sprite.setScale(1.5, 1.5);
    x = 400;
    y = 50;
    speed = 200;
    speed1 = 200;
    active = false;
    beam_interval = 2;
    beam_duration = 3;
    move_interval = 2;
}

void Dragon::activate() {
    active = true;
    sprite.setPosition(x, y);
    beam_timer.restart();
    move_timer.restart();
}
void Dragon::deactivate() {
    active = false;
    StartFireDragon = NULL;
}
void Dragon::newDragon(int a) {
    if (a == 0)
        texture.loadFromFile("img/dragon.png");
    if (a == 1)
        texture.loadFromFile("img/dragon1.png");
    if (a == 2)
        texture.loadFromFile("img/dragon2.png");

    state = a;
}
void Dragon::update(float dt, Player & player) {
    if (!active) {
        return;
    }

    // move left and right

    sprite.setPosition(x, y);

    int player_pos = 0;
    if (player.sprite.getPosition().x < 300)
        player_pos = 0;
    if (player.sprite.getPosition().x >= 300 && player.sprite.getPosition().x < 700)
        player_pos = 1;
    if (player.sprite.getPosition().x >= 700)
        player_pos = 2;
    // fire beam
    if (beam_timer.getElapsedTime().asSeconds() > 2) {
        DragonFire * newFire = new DragonFire(state);
        if (state == 2)
            newFire -> activate(sprite.getPosition() + Vector2f(100, 225));
        else
            newFire -> activate(sprite.getPosition() + Vector2f(145, 375));

        newFire -> LinkFireDragon = StartFireDragon;
        StartFireDragon = newFire;
    }
    DragonFire * current = StartFireDragon;

    while (current != NULL) {
        current -> update(dt, player_pos);
        current = current -> LinkFireDragon;
    }
}
