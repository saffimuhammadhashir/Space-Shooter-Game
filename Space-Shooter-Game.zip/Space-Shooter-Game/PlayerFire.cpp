#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>

#include"PlayerFire.h"


PlayerFire::PlayerFire(int a) {
    if (a == 0 || a == 3) {
        texture.loadFromFile("img/fire01.png");
        sprite.setTexture(texture);
        sprite.setScale(0.35f, 0.35f);
    } else {
        texture.loadFromFile("img/PNG/Effects/fire00.png");
        sprite.setTexture(texture);
        sprite.setScale(1.0f, 1.0f);
    }
}

void PlayerFire::activate(sf::Vector2f position) {
    active = true;
    visible = true;
    sprite.setPosition(position);
}

void PlayerFire::update() {
    if (active) {
        sprite.move(0, -0.5 / 2);
        if (sprite.getPosition().y < 0) {
            active = false;
        }
    }
}
void PlayerFire::updateEnemy() {
    if (active) {
        //sprite.move(0, speed);
        if (sprite.getPosition().y < 0) {
            active = false;
        }
    }
}

void PlayerFire::updatePowerup() {

    if (sprite.getPosition().x < 0 || sprite.getPosition().x > 1030) {
        active = false;
    }
    if (active) {
        sprite.move(pos / 2, -0.2 / 5);

        if (sprite.getPosition().y < 0) {
            active = false;
        }
        // std::cout<<"here"<<std::endl;
    }
}
