#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include"Fire.h"

class DragonFire: public Fire {
    public: 
    DragonFire * LinkFireDragon = NULL;
    Clock FireTime;
    int firecheck;
    DragonFire(int state);
    void activate(sf::Vector2f position) override;
    void update(float time, int direction) ;
};
