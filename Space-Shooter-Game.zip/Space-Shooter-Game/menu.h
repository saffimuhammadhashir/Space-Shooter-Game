#pragma once

#include "game.cpp"


#include<iostream>

#include <SFML/Graphics.hpp>

class Menu {
    public:
        // Add menu attributes here

        Menu() {
            // Constructors body
        }












void display_menu()
{
    // Create the SFML window
    sf::RenderWindow window(sf::VideoMode(800, 600), "Space Shooter");

    // Load font for the game title
    sf::Font font,font1;
    if (!font.loadFromFile("fonts/font2.ttf")) {
        std::cerr << "Failed to load font." << std::endl;
        return ;
    }
    if (!font1.loadFromFile("fonts/font.ttf")) {
        std::cerr << "Failed to load font." << std::endl;
        return ;
    }
    Texture bg_texture;
    bg_texture.loadFromFile("img/background_1.jpg");
    sf::Sprite background(bg_texture);
    // Create game title text
    sf::Text titleText("Space Shooter", font, 70);
    titleText.setFillColor(sf::Color::White);
   // titleText.setStyle(sf::Text::Bold);
    titleText.setPosition(220, 200);

    // Create button rectangle
    sf::RectangleShape button(sf::Vector2f(230, 50));
    button.setFillColor(sf::Color::Green);
    button.setPosition(300, 350);

    // Create button text
    sf::Text buttonText("Start Playing", font1, 30);
    buttonText.setFillColor(sf::Color::Red);
    buttonText.setStyle(sf::Text::Bold);
    buttonText.setPosition(320, 360);

    // Main game loop
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();

            if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::Enter) {
                    // Start playing the game when Enter key is pressed
                    window.close();
                   Game g;
        g.display_menu();
                }
            }

            if (event.type == sf::Event::MouseButtonPressed) {
                if (event.mouseButton.button == sf::Mouse::Left) {
                    // Check if the left mouse button is pressed on the button
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                    if (button.getGlobalBounds().contains(static_cast<sf::Vector2f>(mousePos))) {
                        // Start playing the game when the button is clicked
                        window.close();
                     Game g;
        g.display_menu();
                    }
                }
            }
        }

        // Clear the window
        window.clear();
window.draw(background);
        // Draw the animation or any other background elements

        // Draw the game title
        window.draw(titleText);

        // Draw the button
        window.draw(button);
        window.draw(buttonText);

        // Display the window
        window.display();
    }

    return ;
}
};
/*


class Menu {
    public:
        // Add menu attributes here

        Menu() {
            // Constructors body
        }

    void display_menu() {
                Game *g;
                
                g=new Game;
                g->display_menu();}
                
                };
        /*
        
        // Display menu screen here

        // Add functionality of all the menu options here
        // For example:
        // 1. Start game
        // 2. Options
        // 3. Exit
        
        int choice;
        do {
            // Prompt the user to choose an option
            cout << "Please choose an option:" << endl;
            cout << "1. Start game" << endl;
            cout << "2. Options" << endl;
            cout << "3. Exit" << endl;
            cout << "> ";
            cin >> choice;

            switch (choice) {
            case 1:
            Game *g;
                
                g=new Game;
                g->start_game();
                delete g;
                break;
            case 2: {
                int choiceOption = 0;
                do {

                    cout << "1. View Highscore " << endl;
                    cout << "2. Game level " << endl;
                    cout << "3. Choose space ship " << endl;
                    cin >> choiceOption;

                    switch (choiceOption) {
                    case 1:

                        break;
                    case 2: {

                        break;
                    }

                    case 3:
                        break;
                    default:
                        // Invalid choice
                        cout << "Invalid choice. Please try again." << endl;
                    }
                } while (choiceOption != 3);

            }
            break;
            case 3:
                // Exit the program
                cout << "Exiting..." << endl;
                exit(0);
            default:
                // Invalid choice
                cout << "Invalid choice. Please try again." << endl;
            }
        } while (choice != 3);
    }
    
   
};







*/
