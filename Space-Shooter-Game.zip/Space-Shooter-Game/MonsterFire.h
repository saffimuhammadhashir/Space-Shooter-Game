#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>
#include"Fire.h"

class MonsterFire: public Fire {
    public: 
    MonsterFire * LinkFireMonster = NULL;
    MonsterFire();
    void activate(sf::Vector2f position) override;
    void update(float time) ;

};


