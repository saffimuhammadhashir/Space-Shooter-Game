#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>

#include"PlayerFire.h"

#include "Enemy.h"

#include "Player.cpp"

#include"game.h"

#include<string>

#include"PowerUp.cpp"

#include <fstream>

#include <ostream>
const char title[] = "OOP-Project, Spring-2023";

void Game::start_game() {
    Texture bg_texture1;
    bg_texture1.loadFromFile("img/scoreboard.jpg");
    sf::Sprite background1(bg_texture1);
    background1.setPosition(1080, 0);

    //  RenderWindow start(VideoMode(780, 720), title);   
    delete p;
    int a = spaceship_selection();
    std::string spaceship_paths[] = {
        "img/PNG/playerShip1_blue.png",
        "img/PNG/playerShip1_green.png",
        "img/PNG/playerShip1_orange.png",
        "img/PNG/playerShip1_red.png",
        "img/PNG/playerShip2_blue.png",
        "img/PNG/playerShip2_green.png",
        "img/PNG/playerShip2_orange.png",
        "img/PNG/playerShip2_red.png",
        "img/PNG/playerShip3_blue.png",
        "img/PNG/playerShip3_green.png",
        "img/PNG/playerShip3_orange.png",
        "img/PNG/playerShip3_red.png",
        "img/PNG/ufoRed.png",
        "img/PNG/ufoBlue.png",
        "img/PNG/ufoGreen.png",
        "img/PNG/ufoYellow.png"
    };

    if (a >= 1 && a <= 16) {
        p = new Player(spaceship_paths[a - 1]);
    } else {
        p = new Player("img/player_ship.png");
    }
    RenderWindow window(VideoMode(1280, 780), title);
    p -> name = name;
    srand(time(0));

    sf::Font font;
    font.loadFromFile("fonts/font2.ttf");

    sf::Text ScoreBoard_text("Score Board", font, 35);
    sf::Text alert_text("Life lost", font, 34);
    
     alert_text.setFillColor(sf::Color::Red);
      alert_text.setPosition(1110, 590);

    ScoreBoard_text.setPosition(1080, 50);

    Clock clock;
    float timer = 0;
    /*while(start.isOpen()){
    start.clear(Color::Black); //clears the screen
    start.draw(background1);  // setting background
    	
    if(clock1.getElapsedTime().asSeconds()==5)
    start.close();
    }*/

    Monster m;
    Dragon d;
    PowerUp Pu;
    Clock monster_timer;
    Clock dragon_timer;
    Clock Level_control;
    Clock PowerUp_timer;
    Clock timeenemy;
    Clock Damage_timer;
    Clock life;

    while (window.isOpen()) {
        float time = clock.getElapsedTime().asSeconds();
        clock.restart();
        timer += time;
        Event e;
        while (window.pollEvent(e)) {
            if (e.type == Event::Closed) {
                window.close();

            }
        }
        chkDamage=false;
        sf::Text Score_text("Score: " + std::to_string(score), font, 24);
        sf::Text lives_text("Lives : " + std::to_string(p -> lives), font, 24);
        sf::Text health_text("health : " + std::to_string(p -> health), font, 24);

        Score_text.setPosition(1090, 150);
        lives_text.setPosition(1090, 220);
        health_text.setPosition(1090, 290);

        //sf::Text Scores(std::to_string(score), font, 24);
        //Scores.setPosition(1120, 150);
        int chk = 0;

        Enemy * checkEnemy = StartEnemy;
        while (checkEnemy != NULL) {
            if ((checkEnemy -> active)) {
                chk++;
            }

            checkEnemy = checkEnemy -> LinkEnemy;
        }

        if (!(m.active) && !(d.active))

            if (chk == 0) {
                alpha = true;

                if (Level_control.getElapsedTime().asSeconds() > 3) {
                    std::cout << chk << std::endl;
                    Wavechk++;
                    alpha = false;
                    if (!(Wavechk > 4))
                        for (int j = 0; j < Wavechk - 1; j++)
                            for (int i = 0; i < 10; i++) {
                                int k = (i % 2);
                                Enemy * newEnemy = new Enemy(Levelchk, Wavechk);
                                newEnemy -> activate(Vector2f(50 + i * 100, 60 + k * 50 + 90 * (j + 1)));
                                newEnemy -> LinkEnemy = StartEnemy;
                                StartEnemy = newEnemy;
                            }

                }

            }
        if (chk == 0 && Level_control.getElapsedTime().asSeconds() > 5)
            Level_control.restart();

        if (Wavechk > 4) {
            Wavechk = 1;
            Levelchk++;
            Level_control.restart();

        }
        //  if(Levelchk!=0 && Wavechk==0 && alpha)

        if (m.active || d.active) {
            Enemy * checkEnemy = StartEnemy;
            while (checkEnemy != NULL) {

                checkEnemy -> active = false;
                checkEnemy = checkEnemy -> LinkEnemy;
            }

        }

        specialeffects(m, d, Pu, monster_timer, dragon_timer, PowerUp_timer, * p);
        p -> update();
        // Fire bullets

        if (is_game_over) {
            continue;
        }

        if (Keyboard::isKeyPressed(Keyboard::Left)) {
            p -> move("l");
        }
        if (Keyboard::isKeyPressed(Keyboard::Right)) {
            p -> move("r");
        }
        if (Keyboard::isKeyPressed(Keyboard::Up)) {
            p -> move("u");
        }
        if (Keyboard::isKeyPressed(Keyboard::Down)) {
            p -> move("d");
        }
        if (Keyboard::isKeyPressed(Keyboard::Escape))
            pause_menu(window);

        // Move and update fire sprites
        PlayerFire * current = p -> StartFire, * previous;
        while (current != NULL) {
            if (p -> powerups == 0) {
                current -> updatePowerup();
            } else
                current -> update();
            if (current -> sprite.getPosition().y < 0) {
                previous = current -> LinkFire;

            }
            previous = current;
            current = current -> LinkFire;
        }

        // enemy -> createEnemy(totalEnemiesCreated);
        Enemy * currentEnemy = StartEnemy;
        while (currentEnemy != NULL) {
            currentEnemy -> update(timeenemy);
            if (currentEnemy -> active && rand() % 10000 == 5) {

                currentEnemy -> createFireEnemy(currentEnemy -> sprite.getPosition().x + 25, currentEnemy -> sprite.getPosition().y + (50));
            }
            EnemyFire * Enemycurrent = currentEnemy -> StartFireEnemy, * Enemyprevious;
            while (current != NULL) {

                Enemycurrent -> sprite.move(0, 2);
                if (Enemycurrent -> sprite.getPosition().y < 0) {
                    Enemyprevious = Enemycurrent -> LinkFireEnemy;

                }
                Enemyprevious = Enemycurrent;
                Enemycurrent = Enemycurrent -> LinkFireEnemy;
            }
            currentEnemy = currentEnemy -> LinkEnemy;
        }
        Monster_hit(m, * p);
        Dragon_hit(d, * p);
        player_hit(StartEnemy, p, window);
        PowerUp_hit(Pu, * p, PowerUp_timer);
        enemy_hit(StartEnemy, p, window);
        if (p -> lives <= 0) {
            game_over_screen(window, score, Levelchk, Wavechk);
            is_game_over = true;
        }
        if (is_game_over) {
            add_score_to_file(score, * p);
            assignBadges();
            continue;
        }
        Pu.update(time, * p);
        m.update(time, * p);
        d.update(time, * p);
        window.clear(Color::Black);
        window.draw(background);
        window.draw(background1);
        window.draw(p -> sprite);

        window.draw(ScoreBoard_text);
        window.draw(Score_text);
        window.draw(lives_text);
        window.draw(health_text);
        if(lifelost)
        {window.draw(alert_text);
        life.restart();
        }
        if(life.getElapsedTime().asSeconds()>=5){
        lifelost=false;
        }

        if (m.active) {
            window.draw(m.sprite);

        }
        if (Pu.active) {
            window.draw(Pu.sprite);
        }
        if (d.active) {
            window.draw(d.sprite);

        }
        if (p -> activateshield) {
            window.draw(p -> spriteShield);
            p -> move("");
        }
        

        if(chkDamage){
        
        window.draw(spriteDamage);
        Damage_timer.restart();
        }
        if(Damage_timer.getElapsedTime().asSeconds()>=0.2){
        chkDamage=false;
        
        }

        displaySprites(StartEnemy, p, window, m, d);
        window.draw(p -> sprite); // setting player on screen

        window.display();

    }
}

/*void Game::ReadHighscore()
{
    fstream myfile;
    myfile.open("Highscores.txt", ios::in);

    string temp;

    cout << "\n\n\n\n\n\nDisplaying Highscores           " << endl << endl << endl;
    while (!myfile.eof())
    {
        getline(myfile, temp);

        cout << temp << endl;

    }


}*/
/*
void Game::add_score_to_file(int score, Player& p) {
    std::string insert(p.name + " " + std::to_string(score));
    std::fstream infile, outfile, tempfile;
    infile.open("Highscores.txt");
    tempfile.open("tempfile.txt", std::ios::out | std::ios::trunc);

    // Step 1: Read existing scores from the file into a temporary file
    int max_serial = 0;
    std::string line;
    while (std::getline(infile, line)) {
        int serial = std::stoi(line.substr(0, line.find_first_of(".")));
        max_serial = std::max(max_serial, serial);
        tempfile << line << std::endl;
    }
    infile.close();

    // Step 2: Insert the new score into the temporary file
    int new_serial = max_serial + 1;
    tempfile.seekp(0, std::ios::beg);
    bool inserted = false;
    while (std::getline(tempfile, line)) {
        int serial = std::stoi(line.substr(0, line.find_first_of(".")));
        if (!inserted && score > std::stoi(line.substr(line.find_last_of(" ") + 1))) {
            tempfile << std::to_string(new_serial) << ". " << insert << std::endl;
            inserted = true;
        }
        if (serial >= new_serial && inserted) {
            serial++;
            line.replace(0, line.find_first_of("."), std::to_string(serial));
        }
        outfile << line << std::endl;
    }
    if (!inserted) {
        outfile << std::to_string(new_serial) << ". " << insert << std::endl;
    }
    tempfile.close();
    outfile.close();

    // Step 3: Write the updated scores with serial numbers back to the original file
    infile.open("Highscores.txt", std::ios::out | std::ios::trunc);
    tempfile.open("tempfile.txt");
    while (std::getline(tempfile, line)) {
        infile << line << std::endl;
    }
    infile.close();
    tempfile.close();

    // Step 4: Remove the temporary file
    std::remove("tempfile.txt");
}
*/
void Game::specialeffects(Monster & m, Dragon & d, PowerUp & Pu, Clock & monster_timer, Clock & dragon_timer, Clock & PowerUp_timer, Player & p) {

    int a = rand() % 10 + 40;
    if ((!(m.active) && monster_timer.getElapsedTime().asSeconds() > a) && !(d.active)) {
        int change = rand() % 2;
        m.newMonster(change);
        m.activate();
        monster_timer.restart();

    }

    if ((m.active && monster_timer.getElapsedTime().asSeconds() > 40) || d.active) {
        if (m.active)
            if (!(is_game_over)) score += 40;
        m.deactivate();
        monster_timer.restart();

    }
    int b = a + rand() % 100 + 70;
    if (!(d.active) && dragon_timer.getElapsedTime().asSeconds() > b) {
        int change = rand() % 3;
        d.newDragon(change);
        d.activate();
        dragon_timer.restart();

    }

    if (d.active && dragon_timer.getElapsedTime().asSeconds() > 5) {
        if (d.active)
            if (!(is_game_over)) score += 40;
        d.deactivate();
        dragon_timer.restart();

    }

    int c = 25 + rand() % 60;
    if (!(Pu.active) && PowerUp_timer.getElapsedTime().asSeconds() > c) {
        int change = rand() % 5;
        Pu.newPowerUp(change);
        Pu.activate();

    } else if ((Pu.active) && PowerUp_timer.getElapsedTime().asSeconds() > 5) {
        p.firepower = false;
        p.shield = false;
        p.activateshield = false;
        p.fire7 = false;
        if ((Pu.active) && Pu.sprite.getPosition().y > 800) {

            Pu.deactivate();
            PowerUp_timer.restart();

        }
    }
}

void Game::displaySprites(Enemy * StartEnemy, Player * p, RenderWindow & window, Monster & m, Dragon & d) {
    // Display fire sprites
    sf::Font font;
    font.loadFromFile("fonts/font2.ttf");
    sf::Text Wave1_text("Wave " + std::to_string(Wavechk - 1), font, 24);

    sf::Text Level1_text("Level " + std::to_string(Levelchk), font, 24);

    Wave1_text.setPosition(1090, 430);

    Level1_text.setPosition(1090, 360);
    if (alpha) {

        sf::Text Wave1_text("Wave " + std::to_string(Wavechk), font, 104);

        sf::Text Level1_text("Level " + std::to_string(Levelchk), font, 104);

        Wave1_text.setPosition(400, 400);

        Level1_text.setPosition(440, 280);

        window.draw(Wave1_text);
        window.draw(Level1_text);

    } else {
        window.draw(Wave1_text);
        window.draw(Level1_text);
    }

    MonsterFire * Monstercurrent = m.StartFireMonster;
    while (Monstercurrent != NULL) {
        if (Monstercurrent -> active && Monstercurrent -> visible) {
            window.draw(Monstercurrent -> sprite);
        }
        Monstercurrent = Monstercurrent -> LinkFireMonster;
    }

    DragonFire * Dragoncurrent = d.StartFireDragon;
    while (Dragoncurrent != NULL) {
        if (Dragoncurrent -> active && Dragoncurrent -> visible) {
            window.draw(Dragoncurrent -> sprite);
        }
        Dragoncurrent = Dragoncurrent -> LinkFireDragon;
    }

    Enemy * currentEnemy = StartEnemy;
    while (currentEnemy != NULL) {

        EnemyFire * Enemycurrent = currentEnemy -> StartFireEnemy;
        while (Enemycurrent != NULL) {
            if (Enemycurrent -> active && Enemycurrent -> visible) {
                window.draw(Enemycurrent -> sprite);
            }
            Enemycurrent = Enemycurrent -> LinkFireEnemy;
        }
        currentEnemy = currentEnemy -> LinkEnemy;
    }

    PlayerFire * currentFire = p -> StartFire;
    while (currentFire != NULL) {
        if (currentFire -> active && currentFire -> visible) {
            window.draw(currentFire -> sprite);
        }
        currentFire = currentFire -> LinkFire;
    }

    // Display enemy sprites
    currentEnemy = StartEnemy;
    while (currentEnemy != NULL) {
        if (currentEnemy -> active) {
            window.draw(currentEnemy -> sprite);

        }
        currentEnemy = currentEnemy -> LinkEnemy;
    }

}

void Game::enemy_hit(Enemy * StartEnemy, Player * p, RenderWindow & window) {

    // loop through all fire sprites and check collision with enemy sprites
    PlayerFire * currentFire = p -> StartFire, * previousFire = nullptr;
    while (currentFire != NULL) {
        // check collision with each enemy sprite
        Enemy * currentEnemy = StartEnemy, * previousEnemy = nullptr;
        while (currentEnemy != NULL) {

            if (currentEnemy -> active && currentEnemy -> sprite.getGlobalBounds().intersects(p -> sprite.getGlobalBounds()) && !(p -> shield)) {
                p -> health--;
                if (p -> health == 0) {
                    p -> lives--;
                    p -> health = 10000.000;
                            lifelost=true;
                }
          chkDamage=true;      
spriteDamage.setPosition(p->sprite.getPosition());
            }
            if (currentEnemy -> active && currentFire -> sprite.getGlobalBounds().intersects(currentEnemy -> sprite.getGlobalBounds())) {
                // fire sprite has collided with enemy sprite

                currentEnemy -> health = currentEnemy -> health - 10;
                currentFire -> visible = false;
                if (currentEnemy -> health == 0) {
                    currentEnemy -> active = false;
                    if (!(p -> firepower)) {
                        currentFire -> active = false;
                    }
                    score = score + (10 * (currentEnemy -> LevelEnemy) * Levelchk);
                    if (previousEnemy != nullptr) {
                        previousEnemy -> LinkEnemy = currentEnemy -> LinkEnemy;
                    } else {
                        StartEnemy = currentEnemy -> LinkEnemy;
                    }
                    break;
                }
          chkDamage=true;      
spriteDamage.setPosition(currentEnemy->sprite.getPosition());
            }
            previousEnemy = currentEnemy;
            currentEnemy = currentEnemy -> LinkEnemy;
        }

        if (currentFire -> active == false) {
            if (!(p -> firepower)) {
                // remove fire sprite from list
                if (previousFire != nullptr) {
                    previousFire -> LinkFire = currentFire -> LinkFire;
                } else {
                    p -> StartFire = currentFire -> LinkFire;
                }
                PlayerFire * temp = currentFire;

                delete temp;
            }
        } else {
            previousFire = currentFire;

        }
        currentFire = currentFire -> LinkFire;
    }
    Fire_hit(StartEnemy, p, window);

    /* // loop through all fire sprites and check collision with enemy sprites
     Fire * currentFire = p -> StartFire, * previousFire = nullptr;
     while (currentFire != NULL) {
         // check collision with each enemy sprite
         Enemy * currentEnemy = StartEnemy, * previousEnemy = nullptr;
         while (currentEnemy != NULL) {
             if (currentEnemy -> active && currentFire -> sprite.getGlobalBounds().intersects(currentEnemy -> sprite.getGlobalBounds())) {
                 // fire sprite has collided with enemy sprite
                 currentEnemy -> health = currentEnemy -> health - 5;

                 if (currentEnemy -> health == 0) {
                 currentFire -> active = false;
                     currentEnemy -> active = false;
                     score = score + (100 * (currentEnemy -> LevelEnemy + 1));
                     if (previousEnemy != nullptr) {
                         previousEnemy -> LinkEnemy = currentEnemy -> LinkEnemy;
                     } else {
                         StartEnemy = currentEnemy -> LinkEnemy;
                     }
                     break;
                 }
             }

             if (currentFire -> sprite.getGlobalBounds().intersects(currentEnemy -> sprite.getGlobalBounds())) {
                 // fire sprite has collided with enemy sprite
                 currentFire -> active = false;
                 break;
             }

             previousEnemy = currentEnemy;
             currentEnemy = currentEnemy -> LinkEnemy;
         }

         if (currentFire -> active == false) {
             // remove fire sprite from list
             if (previousFire != nullptr) {
                 previousFire -> LinkFire = currentFire -> LinkFire;
             } else {
                 p -> StartFire = currentFire -> LinkFire;
             }
             Fire * temp = currentFire;
             currentFire = currentFire -> LinkFire;
             delete temp;
         } else {
             previousFire = currentFire;
             currentFire = currentFire -> LinkFire;
         }
     }*/

}
void Game::PowerUp_hit(PowerUp & Pu, Player & p, Clock & PowerUp_timer) {
    if (PowerUp_timer.getElapsedTime().asSeconds() > 5) {
        p.powerups = -1;
    }

    if (!(Pu.active)) {
        return;
    } else if (Pu.sprite.getGlobalBounds().intersects(p.sprite.getGlobalBounds()) && PowerUp_timer.getElapsedTime().asSeconds() > 3) {
        p.powerups = Pu.type;
if(Pu.type==4){lifelost=true;}
        Pu.active = false;
        PowerUp_timer.restart();
    }

}
void Game::Fire_hit(Enemy * StartEnemy, Player * p, RenderWindow & window) {

    /*
    Fire * currentFire = p -> StartFire, * previousFire = nullptr;
        while (currentFire != NULL) {
            // check collision with each enemy sprite
            Enemy * currentEnemy = StartEnemy, * previousEnemy = nullptr;
            while (currentEnemy != NULL) {
                if (currentEnemy -> active && currentFire -> sprite.getGlobalBounds().intersects(currentEnemy -> sprite.getGlobalBounds())) {
                    // fire sprite has collided with enemy sprite
                    currentEnemy -> health = currentEnemy -> health - 5;

                    if (currentEnemy -> health == 0) {
                    currentFire -> active = false;
                        currentEnemy -> active = false;
                        score = score + (100 * (currentEnemy -> LevelEnemy + 1));
                        if (previousEnemy != nullptr) {
                            previousEnemy -> LinkEnemy = currentEnemy -> LinkEnemy;
                        } else {
                            StartEnemy = currentEnemy -> LinkEnemy;
                        }
                        break;
                    }
                }

                if (currentFire -> sprite.getGlobalBounds().intersects(currentEnemy -> sprite.getGlobalBounds())) {
                    // fire sprite has collided with enemy sprite
                    currentFire -> active = false;
                    break;
                }

                previousEnemy = currentEnemy;
                currentEnemy = currentEnemy -> LinkEnemy;
            }

            if (currentFire -> active == false) {
                // remove fire sprite from list
                if (previousFire != nullptr) {
                    previousFire -> LinkFire = currentFire -> LinkFire;
                } else {
                    p -> StartFire = currentFire -> LinkFire;
                }
                Fire * temp = currentFire;
                currentFire = currentFire -> LinkFire;
                delete temp;
            } else {
                previousFire = currentFire;
                currentFire = currentFire -> LinkFire;
            }
        }*/
}

void Game::player_hit(Enemy * StartEnemy, Player * p, RenderWindow & window) {

    if (StartEnemy != NULL) {

        EnemyFire * CurrentEnemyFire = StartEnemy -> StartFireEnemy, * PreviousEnemyFire = nullptr;
        while (CurrentEnemyFire != NULL) {

            Enemy * CurrentEnemy = StartEnemy;
            while (CurrentEnemy != NULL) {

                if (CurrentEnemyFire -> sprite.getGlobalBounds().intersects(p -> sprite.getGlobalBounds()) && !(p -> shield)) {
                    p -> health--;
                    CurrentEnemyFire -> visible = false;
                    if (p -> health == 0) {
                        p -> lives--;
                        p -> health = 10000.000;
                                lifelost=true;
                        CurrentEnemyFire -> active = false;

                    }
                              chkDamage=true;      
spriteDamage.setPosition(p->sprite.getPosition());
                }
                CurrentEnemy = CurrentEnemy -> LinkEnemy;
            }

            if (CurrentEnemyFire -> active == false) {
                // remove fire sprite from list
                if (PreviousEnemyFire != nullptr) {
                    PreviousEnemyFire -> LinkFireEnemy = CurrentEnemyFire -> LinkFireEnemy;
                } else {
                    StartEnemy -> StartFireEnemy = CurrentEnemyFire -> LinkFireEnemy;
                }
                EnemyFire * temp = CurrentEnemyFire;
                CurrentEnemyFire = CurrentEnemyFire -> LinkFireEnemy;
                delete temp;
            } else {
                PreviousEnemyFire = CurrentEnemyFire;
                CurrentEnemyFire = CurrentEnemyFire -> LinkFireEnemy;
            }
        }
    }

}

void Game::Monster_hit(Monster & m, Player & p) {
    if (m.active) {
        MonsterFire * CurrentMonsterFire = m.StartFireMonster;
        MonsterFire * PreviousMonsterFire = nullptr;

        if (m.sprite.getGlobalBounds().intersects(p.sprite.getGlobalBounds()) && !(p.shield)) {
            p.health--;
            if (p.health == 0) {
                p.lives--;
                p.health = 10000.000;
                        lifelost=true;
            }
          chkDamage=true;      
spriteDamage.setPosition(p.sprite.getPosition());
        }

        while (CurrentMonsterFire != nullptr) {
            if (CurrentMonsterFire -> sprite.getGlobalBounds().intersects(p.sprite.getGlobalBounds()) && !(p.shield)) {
                p.health--;
                if (p.health == 0) {
                    p.lives--;
                    p.health = 10000.000;
                            lifelost=true;
                }
                          chkDamage=true;      
spriteDamage.setPosition(p.sprite.getPosition());

            }

            if (CurrentMonsterFire -> active == false) {
                if (PreviousMonsterFire != nullptr) {
                    PreviousMonsterFire -> LinkFireMonster = CurrentMonsterFire -> LinkFireMonster;
                } else {
                    m.StartFireMonster = CurrentMonsterFire -> LinkFireMonster;
                }
                delete CurrentMonsterFire;
                CurrentMonsterFire = nullptr;
            } else {
                PreviousMonsterFire = CurrentMonsterFire;
                CurrentMonsterFire = CurrentMonsterFire -> LinkFireMonster;
            }
        }
    }
}

void Game::Dragon_hit(Dragon & d, Player & p) {
    if (d.active) {
        DragonFire * CurrentDragonFire = d.StartFireDragon;
        DragonFire * PreviousDragonFire = nullptr;
        if (d.sprite.getGlobalBounds().intersects(p.sprite.getGlobalBounds()) && !(p.shield)) {
            p.health--;
            if (p.health == 0) {
                p.lives--;
                p.health = 10000.000;
                        lifelost=true;
            }
                      chkDamage=true;      
spriteDamage.setPosition(p.sprite.getPosition());

        }
        while (CurrentDragonFire != nullptr) {
            if (CurrentDragonFire -> sprite.getGlobalBounds().intersects(p.sprite.getGlobalBounds()) && !(p.shield)) {
                p.health--;
                if (p.health == 0) {
                    p.lives--;
                    p.health = 10000.000;
                            lifelost=true;
                }
                          chkDamage=true;      
spriteDamage.setPosition(p.sprite.getPosition());

            }

            if (CurrentDragonFire -> active == false) {
                if (PreviousDragonFire != nullptr) {
                    PreviousDragonFire -> LinkFireDragon = CurrentDragonFire -> LinkFireDragon;
                } else {
                    d.StartFireDragon = CurrentDragonFire -> LinkFireDragon;
                }
                delete CurrentDragonFire;
                CurrentDragonFire = nullptr;
            } else {
                PreviousDragonFire = CurrentDragonFire;
                CurrentDragonFire = CurrentDragonFire -> LinkFireDragon;
            }
        }
    }
}

/*
void Player::FIRE() {

Fire* current=StartFire;

    if (StartFire==nullptr) {
    StartFire=new Fire;

        StartFire->LinkFire=NULL;
        
    StartFire->activate(sf::Vector2f(sprite.getPosition().x, sprite.getPosition().y));
    }
    else{
    while(current!=nullptr){

    current=current->LinkFire;}

    current=new Fire;    
    current->LinkFire=NULL;
       
    current->activate(sf::Vector2f(sprite.getPosition().x, sprite.getPosition().y)); 
    }
}*/
//+sprite.getGlobalBounds().width / 2 - fire.sprite.getGlobalBounds().width / 2
// - fire.sprite.getGlobalBounds().height

















































void Game::display_menu() {

    // Create window
    sf::RenderWindow window(sf::VideoMode(1080, 780), "Menu");

    // Create menu options
    sf::Font font;
    font.loadFromFile("fonts/font2.ttf");
    sf::Text start_text("1. Start Game", font, 54);
    sf::Text options_text("2. Highscores", font, 54);
    sf::Text exit_text("3. Exit", font, 54);
    start_text.setPosition(440, 200);
    options_text.setPosition(460, 375);
    exit_text.setPosition(490, 550);
    menuSound.play();

    // Set up background image
    sf::Texture bg_texture;
    bg_texture.loadFromFile("img/background2.jpg");
    sf::Sprite background(bg_texture);

    // Display menu screen
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
            // Handle mouse events
            if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2i mouse_position = sf::Mouse::getPosition(window);
                if (start_text.getGlobalBounds().contains(mouse_position.x, mouse_position.y)) {
                    // Start game

                    menuSound.stop();
                    getPlayerName(window);

                } else if (options_text.getGlobalBounds().contains(mouse_position.x, mouse_position.y)) {
                    // Options
                    window.close();
                    displayFileContent("Highscores.txt");
                    // TODO: Add options screen
                } else if (exit_text.getGlobalBounds().contains(mouse_position.x, mouse_position.y)) {
                    // Exit
                    window.close();
                }
            }
            if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::Num1) {
                    // Start game

                    menuSound.stop();
                    getPlayerName(window);

                } else if (event.key.code == sf::Keyboard::Num2) {
                    // Options
                    window.close();
                    displayFileContent("Highscores.txt");
                    // TODO: Add options screen
                } else if (event.key.code == sf::Keyboard::Num3) {
                    // Exit
                    window.close();
                } else if (event.key.code == sf::Keyboard::Escape) {
                    // Pause game
                    //pause_menu(window);
                }
            }
        }

        window.clear(sf::Color::Black);
        window.draw(background);
        window.draw(start_text);
        window.draw(options_text);
        window.draw(exit_text);
        window.display();
    }
}

void Game::pause_menu(RenderWindow & old) {
    // Create window
    sf::RenderWindow window(sf::VideoMode(1080, 780), "GAME PAUSE");

    // Create menu options
    sf::Font font;
    font.loadFromFile("fonts/font1.otf");
    sf::Text resume_text("1. Resume Game", font, 34);
    sf::Text start_text("2. Restart Game", font, 34);
    sf::Text options_text("3. Highscores", font, 34);
    sf::Text exit_text("4. Exit", font, 34);
    resume_text.setPosition(470, 200);
    start_text.setPosition(470, 300);
    options_text.setPosition(480, 400);
    exit_text.setPosition(490, 500);
    PausemenuSound.play();

    // Set up background image
    sf::Texture bg_texture;
    bg_texture.loadFromFile("img/background_1.jpg");
    sf::Sprite background(bg_texture);

    // Display menu screen
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                PausemenuSound.stop();
                window.close();

            }
            // Handle mouse events
            if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2i mouse_position = sf::Mouse::getPosition(window);

                if (start_text.getGlobalBounds().contains(mouse_position.x, mouse_position.y)) {
                    // Start game
                    old.close();
                    window.close();
                    PausemenuSound.stop();
                  Game g;
        g.display_menu();


                }
                if (resume_text.getGlobalBounds().contains(mouse_position.x, mouse_position.y)) {
                    // Start game
                    PausemenuSound.stop();
                    window.close();

                } else if (options_text.getGlobalBounds().contains(mouse_position.x, mouse_position.y)) {
                    old.close();
                    window.close();
                    displayFileContent("Highscores.txt");
                    // Options
                    // TODO: Add options screen
                } else if (exit_text.getGlobalBounds().contains(mouse_position.x, mouse_position.y)) {
                    // Exit
                    window.close();
                    old.close();

                }
            }
            if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::Num1) {
                    // Start game
                    PausemenuSound.stop();
                    window.close();

                } else if (event.key.code == sf::Keyboard::Num2) {
                    // Start game

                    old.close();
                    window.close();
                    PausemenuSound.stop();
                  Game g;
        g.display_menu();

                } else if (event.key.code == sf::Keyboard::Num3) {
                    // Options
                     old.close();
                    window.close();
                    displayFileContent("Highscores.txt");
                    // TODO: Add options screen
                } else if (event.key.code == sf::Keyboard::Num4) {
                    // Exit
                    window.close();
                    old.close();

                } else if (event.key.code == sf::Keyboard::Escape) {
                    // Pause game
                    //pause_menu(window);

                    window.close();

                }
            }
        }

        window.clear(sf::Color::Black);
        window.draw(background);
        window.draw(resume_text);
        window.draw(start_text);
        window.draw(options_text);
        window.draw(exit_text);
        window.display();
    }
}
void Game::load_screen() {
    // Create a window
    sf::RenderWindow window(sf::VideoMode(800, 600), "Loading Screen");

    // Create the font and text objects for the countdown
    sf::Font font;
    font.loadFromFile("fonts/font1.otf");
    sf::Texture bg_texture;
    bg_texture.loadFromFile("img/background_1.jpg");
    sf::Sprite background(bg_texture);
    sf::Text a_text("1", font, 200);
    sf::Text b_text("2", font, 200);
    sf::Text c_text("3", font, 200);
    sf::Text play_text("Let's Play", font, 200);

    a_text.setPosition(350, 200);
    b_text.setPosition(350, 200);
    c_text.setPosition(350, 200);
    play_text.setPosition(50, 180);
    window.clear();
    window.draw(background);
    window.draw(a_text);
    window.display();
    sf::sleep(sf::seconds(1));
    window.clear();
    window.draw(background);
    window.draw(b_text);
    window.display();
    sf::sleep(sf::seconds(1));
    window.clear();
    window.draw(background);
    window.draw(c_text);
    window.display();
    sf::sleep(sf::seconds(1));
    window.clear();
    window.draw(background);
    window.draw(play_text);
    window.display();
    sf::sleep(sf::seconds(1));

    window.display();

    window.close();

    start_game();

}
/*
void Game::spaceship_selection() {
    sf::RenderWindow window(sf::VideoMode(800, 600), "Spaceship Selection");
    

    // Create the font and text objects for the countdown
    sf::Font font;
    font.loadFromFile("fonts/font1.otf");
    sf::Texture bg_texture;
    bg_texture.loadFromFile("img/background_1.jpg");
    sf::Sprite background(bg_texture);
    int x=400,y=300;
    
    
    
    
    
    
    sf::Texture tex2;
    sf::Sprite sprite2;
    tex2.loadFromFile("img/PNG/playerShip1_blue.png");
    sprite2.setTexture(tex2);
    sprite2.setPosition(sf::Vector2f(x, y));
    sprite2.setScale(0.75, 0.75);
    
    
    
    sf::Texture tex3;
    sf::Sprite sprite3;
    tex3.loadFromFile("img/PNG/playerShip1_green.png");
    sprite3.setTexture(tex3);
    sprite3.setPosition(sf::Vector2f(x, y));
    sprite3.setScale(0.75, 0.75);
        
    
    
    sf::Texture tex4;
    sf::Sprite sprite4;
    tex4.loadFromFile("img/PNG/playerShip1_orange.png");
    sprite4.setTexture(tex4);
    sprite4.setPosition(sf::Vector2f(x, y));
    sprite4.setScale(0.75, 0.75);
        
    
    
    sf::Texture tex5;
    sf::Sprite sprite5;
    tex5.loadFromFile("img/PNG/playerShip1_red.png");
    sprite5.setTexture(tex5);
    sprite5.setPosition(sf::Vector2f(x, y));
    sprite5.setScale(0.75, 0.75);
    
    
        
    sf::Texture tex6;
    sf::Sprite sprite6;
    tex6.loadFromFile("img/PNG/playerShip2_blue.png");
    sprite6.setTexture(tex6);
    sprite6.setPosition(sf::Vector2f(x, y));
    sprite6.setScale(0.75, 0.75);
    
    
    
    sf::Texture tex7;
    sf::Sprite sprite7;
    tex7.loadFromFile("img/PNG/playerShip2_green.png");
    sprite7.setTexture(tex7);
    sprite7.setPosition(sf::Vector2f(x, y));
    sprite7.setScale(0.75, 0.75);
        
    
    
    sf::Texture tex8;
    sf::Sprite sprite8;
    tex8.loadFromFile("img/PNG/playerShip2_orange.png");
    sprite8.setTexture(tex8);
    sprite8.setPosition(sf::Vector2f(x, y));
    sprite8.setScale(0.75, 0.75);
        
    
    
    sf::Texture tex9;
    sf::Sprite sprite9;
    tex5.loadFromFile("img/PNG/playerShip2_red.png");
    sprite9.setTexture(tex9);
    sprite9.setPosition(sf::Vector2f(x, y));
    sprite9.setScale(0.75, 0.75);
    
        
    sf::Texture tex11;
    sf::Sprite sprite11;
    tex11.loadFromFile("img/PNG/playerShip3_blue.png");
    sprite11.setTexture(tex11);
    sprite11.setPosition(sf::Vector2f(x, y));
    sprite11.setScale(0.75, 0.75);
    
    
    
    sf::Texture tex12;
    sf::Sprite sprite12;
    tex12.loadFromFile("img/PNG/playerShip3_green.png");
    sprite12.setTexture(tex12);
    sprite12.setPosition(sf::Vector2f(x, y));
    sprite12.setScale(0.75, 0.75);
        
    
    
    sf::Texture tex13;
    sf::Sprite sprite13;
    tex13.loadFromFile("img/PNG/playerShip3_orange.png");
    sprite13.setTexture(tex13);
    sprite13.setPosition(sf::Vector2f(x, y));
    sprite13.setScale(0.75, 0.75);
        
    
    
    sf::Texture tex14;
    sf::Sprite sprite14;
    tex14.loadFromFile("img/PNG/playerShip3_red.png");
    sprite14.setTexture(tex14);
    sprite14.setPosition(sf::Vector2f(x, y));
    sprite14.setScale(0.75, 0.75);
    
    
    
    sf::Texture tex15;
    sf::Sprite sprite15;
    tex15.loadFromFile("img/PNG/ufoRed.png");
    sprite15.setTexture(tex15);
    sprite15.setPosition(sf::Vector2f(x, y));
    sprite15.setScale(0.75, 0.75);
    
    
        
    sf::Texture tex16;
    sf::Sprite sprite16;
    tex16.loadFromFile("img/PNG/ufoBlue.png");
    sprite16.setTexture(tex16);
    sprite16.setPosition(sf::Vector2f(x, y));
    sprite16.setScale(0.75, 0.75);
    
    
    
    sf::Texture tex17;
    sf::Sprite sprite17;
    tex17.loadFromFile("img/PNG/ufoGreen.png");
    sprite17.setTexture(tex17);
    sprite17.setPosition(sf::Vector2f(x, y));
    sprite17.setScale(0.75, 0.75);
        
    
    
    sf::Texture tex18;
    sf::Sprite sprite18;
    tex18.loadFromFile("img/PNG/ufoYellow.png");
    sprite18.setTexture(tex18);
    sprite18.setPosition(sf::Vector2f(x, y));
    sprite18.setScale(0.75, 0.75);

    
    
    
    sf::Text a_text("1", font, 200);
    sf::Text b_text("2", font, 200);
    sf::Text c_text("3", font, 200);
    sf::Text play_text("Let's Play", font, 200);
     

    a_text.setPosition(350, 200);
    b_text.setPosition(350, 200);
    c_text.setPosition(350, 200);
    play_text.setPosition(50, 180);
    
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                PausemenuSound.stop();
                window.close();

            }
    window.clear(sf::Color::Black);
    window.draw(background);
        window.draw(background);
        window.draw(sprite2);
        window.display();}
}}
*/

int Game::spaceship_selection() {
    sf::RenderWindow window(sf::VideoMode(1200, 650), "Spaceship Selection");

    // Load font and create text objects for spaceship numbers

    //Game background sprite
    Texture bg_texture1;
    bg_texture1.loadFromFile("img/background1.jpg");
    sf::Sprite background1(bg_texture1);
    sf::Font font, font1;
    font1.loadFromFile("fonts/font1.otf");
    font.loadFromFile("fonts/font.ttf");

    int size = 45;
    sf::Text Supership("Super Ship", font, size - 5);
    sf::Text a_text("A", font, size);
    sf::Text b_text("B", font, size);
    sf::Text c_text("C", font, size);
    sf::Text d_text("D", font, size);
    sf::Text e_text("E", font, size);
    sf::Text f_text("F", font, size);
    sf::Text g_text("G", font, size);
    sf::Text h_text("H", font, size);
    sf::Text i_text("I", font, size);

    sf::Text j_text("J", font, size);
    sf::Text k_text("K", font, size);
    sf::Text l_text("L", font, size);
    sf::Text m_text("M", font, size);
    sf::Text n_text("N", font, size);
    sf::Text o_text("O", font, size);
    sf::Text p_text("P", font, size);
    sf::Text q_text("Q", font, size);
    int x = 90, y = 80;
    sf::Texture tex1;
    sf::Sprite sprite1;
    tex1.loadFromFile("img/player_ship.png");
    sprite1.setTexture(tex1);
    sprite1.setPosition(sf::Vector2f(1070, 375));
    sprite1.setScale(1, 1);

    // Load textures and create sprite objects for each spaceship
    sf::Texture tex2;
    sf::Sprite sprite2;
    tex2.loadFromFile("img/PNG/playerShip1_blue.png");
    sprite2.setTexture(tex2);
    sprite2.setPosition(sf::Vector2f(x, y));
    sprite2.setScale(1, 1);

    x += 250;

    sf::Texture tex3;
    sf::Sprite sprite3;
    tex3.loadFromFile("img/PNG/playerShip1_green.png");
    sprite3.setTexture(tex3);
    sprite3.setPosition(sf::Vector2f(x, y));
    sprite3.setScale(1, 1);

    x += 250;

    sf::Texture tex4;
    sf::Sprite sprite4;
    tex4.loadFromFile("img/PNG/playerShip1_orange.png");
    sprite4.setTexture(tex4);
    sprite4.setPosition(sf::Vector2f(x, y));
    sprite4.setScale(0.75, 0.75);

    x += 250;

    sf::Texture tex5;
    sf::Sprite sprite5;
    tex5.loadFromFile("img/PNG/playerShip1_red.png");
    sprite5.setTexture(tex5);
    sprite5.setPosition(sf::Vector2f(x, y));
    sprite5.setScale(0.75, 0.75);

    x = 90;
    y += 150;

    sf::Texture tex6;
    sf::Sprite sprite6;
    tex6.loadFromFile("img/PNG/playerShip2_blue.png");
    sprite6.setTexture(tex6);
    sprite6.setPosition(sf::Vector2f(x, y));
    sprite6.setScale(0.75, 0.75);

    x += 250;

    sf::Texture tex7;
    sf::Sprite sprite7;
    tex7.loadFromFile("img/PNG/playerShip2_green.png");
    sprite7.setTexture(tex7);
    sprite7.setPosition(sf::Vector2f(x, y));
    sprite7.setScale(0.75, 0.75);

    x += 250;

    sf::Texture tex8;
    sf::Sprite sprite8;
    tex8.loadFromFile("img/PNG/playerShip2_orange.png");
    sprite8.setTexture(tex8);
    sprite8.setPosition(sf::Vector2f(x, y));
    sprite8.setScale(0.75, 0.75);

    x += 250;

    sf::Texture tex9;
    sf::Sprite sprite9;
    tex9.loadFromFile("img/PNG/playerShip2_red.png");
    sprite9.setTexture(tex9);
    sprite9.setPosition(sf::Vector2f(x, y));
    sprite9.setScale(0.75, 0.75);

    x = 90;
    y += 150;
    sf::Texture tex11;
    sf::Sprite sprite11;
    tex11.loadFromFile("img/PNG/playerShip3_blue.png");
    sprite11.setTexture(tex11);
    sprite11.setPosition(sf::Vector2f(x, y));
    sprite11.setScale(0.75, 0.75);

    x += 250;

    sf::Texture tex12;
    sf::Sprite sprite12;
    tex12.loadFromFile("img/PNG/playerShip3_green.png");
    sprite12.setTexture(tex12);
    sprite12.setPosition(sf::Vector2f(x, y));
    sprite12.setScale(1, 1);

    x += 250;

    sf::Texture tex13;
    sf::Sprite sprite13;
    tex13.loadFromFile("img/PNG/playerShip3_orange.png");
    sprite13.setTexture(tex13);
    sprite13.setPosition(sf::Vector2f(x, y));
    sprite13.setScale(0.75, 0.75);

    x += 250;

    sf::Texture tex14;
    sf::Sprite sprite14;
    tex14.loadFromFile("img/PNG/playerShip3_red.png");
    sprite14.setTexture(tex14);
    sprite14.setPosition(sf::Vector2f(x, y));
    sprite14.setScale(0.75, 0.75);

    x = 90;
    y += 150;
    sf::Texture tex15;
    sf::Sprite sprite15;
    tex15.loadFromFile("img/PNG/ufoRed.png");
    sprite15.setTexture(tex15);
    sprite15.setPosition(sf::Vector2f(x, y));
    sprite15.setScale(0.75, 0.75);

    x += 250;

    sf::Texture tex16;
    sf::Sprite sprite16;
    tex16.loadFromFile("img/PNG/ufoBlue.png");
    sprite16.setTexture(tex16);
    sprite16.setPosition(sf::Vector2f(x, y));
    sprite16.setScale(0.75, 0.75);

    x += 250;

    sf::Texture tex17;
    sf::Sprite sprite17;
    tex17.loadFromFile("img/PNG/ufoGreen.png");
    sprite17.setTexture(tex17);
    sprite17.setPosition(sf::Vector2f(x, y));
    sprite17.setScale(0.75, 0.75);

    x += 250;

    sf::Texture tex18;
    sf::Sprite sprite18;
    tex18.loadFromFile("img/PNG/ufoYellow.png");
    sprite18.setTexture(tex18);
    sprite18.setPosition(sf::Vector2f(x, y));
    sprite18.setScale(0.75, 0.75);

    // Set initial positions and scales for the spaceship sprites and text objects
    const float scale = 1;

    sprite1.setScale(scale, scale);
    sprite2.setScale(scale, scale);
    sprite3.setScale(scale, scale);
    sprite4.setScale(scale, scale);
    sprite5.setScale(scale, scale);
    sprite6.setScale(scale, scale);
    sprite7.setScale(scale, scale);
    sprite8.setScale(scale, scale);
    sprite9.setScale(scale, scale);
    sprite11.setScale(scale, scale);
    sprite12.setScale(scale, scale);
    sprite13.setScale(scale, scale);
    sprite14.setScale(scale, scale);
    sprite15.setScale(scale, scale);
    sprite16.setScale(scale, scale);
    sprite17.setScale(scale, scale);
    sprite18.setScale(scale, scale);
    int a = -80, b = 85;
    Supership.setPosition(sprite1.getPosition().x + a, sprite1.getPosition().y - b);
    a_text.setPosition(sprite2.getPosition().x + a, sprite2.getPosition().y - b);
    b_text.setPosition(sprite3.getPosition().x + a, sprite3.getPosition().y - b);
    c_text.setPosition(sprite4.getPosition().x + a, sprite4.getPosition().y - b);
    d_text.setPosition(sprite5.getPosition().x + a, sprite5.getPosition().y - b);
    e_text.setPosition(sprite6.getPosition().x + a, sprite6.getPosition().y - b);
    f_text.setPosition(sprite7.getPosition().x + a, sprite7.getPosition().y - b);
    g_text.setPosition(sprite8.getPosition().x + a, sprite8.getPosition().y - b);
    h_text.setPosition(sprite9.getPosition().x + a, sprite9.getPosition().y - b);
    i_text.setPosition(sprite11.getPosition().x + a, sprite11.getPosition().y - b);
    j_text.setPosition(sprite12.getPosition().x + a, sprite12.getPosition().y - b);
    k_text.setPosition(sprite13.getPosition().x + a, sprite13.getPosition().y - b);
    l_text.setPosition(sprite14.getPosition().x + a, sprite14.getPosition().y - b);
    m_text.setPosition(sprite15.getPosition().x + a, sprite15.getPosition().y - b);
    n_text.setPosition(sprite16.getPosition().x + a, sprite16.getPosition().y - b);
    o_text.setPosition(sprite17.getPosition().x + a, sprite17.getPosition().y - b);
    p_text.setPosition(sprite18.getPosition().x + a, sprite18.getPosition().y - b);
    q_text.setPosition(sprite1.getPosition().x + 20 + a, sprite1.getPosition().y);

    int selected_spaceship = 0;
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
                display_menu();
            } else if (event.type == sf::Event::MouseButtonPressed) {
                if (event.mouseButton.button == sf::Mouse::Left) {
                    // Check if the mouse was clicked on one of the spaceship sprites
                    sf::Vector2f mouse_pos(event.mouseButton.x, event.mouseButton.y);
                    if (sprite1.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite1
                        selected_spaceship = 17;
                    } else if (sprite2.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite1
                        selected_spaceship = 1;
                    } else if (sprite3.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite2
                        selected_spaceship = 2;
                    } else if (sprite4.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 3;
                    } else if (sprite5.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 4;
                    } else if (sprite6.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 5;
                    } else if (sprite7.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 6;
                    } else if (sprite8.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 7;
                    } else if (sprite9.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 8;
                    } else if (sprite11.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 9;
                    } else if (sprite12.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 10;
                    } else if (sprite13.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 11;
                    } else if (sprite14.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 12;
                    } else if (sprite15.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 13;
                    } else if (sprite16.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 14;
                    } else if (sprite17.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 15;
                    } else if (sprite18.getGlobalBounds().contains(mouse_pos)) {
                        // Set the selected spaceship to sprite3
                        selected_spaceship = 16;
                    }
                }
            }

            if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::A) {
                    // Start game
                    selected_spaceship = 1;

                } else if (event.key.code == sf::Keyboard::B) {
                    // Start game
                    selected_spaceship = 2;

                } else if (event.key.code == sf::Keyboard::C) {
                    // Start game
                    selected_spaceship = 3;

                } else if (event.key.code == sf::Keyboard::D) {
                    // Start game
                    selected_spaceship = 4;

                } else if (event.key.code == sf::Keyboard::E) {
                    // Start game
                    selected_spaceship = 5;

                } else if (event.key.code == sf::Keyboard::F) {
                    // Start game
                    selected_spaceship = 6;

                } else if (event.key.code == sf::Keyboard::G) {
                    // Start game
                    selected_spaceship = 7;

                } else if (event.key.code == sf::Keyboard::H) {
                    // Start game
                    selected_spaceship = 8;

                } else if (event.key.code == sf::Keyboard::I) {
                    // Start game
                    selected_spaceship = 9;

                } else if (event.key.code == sf::Keyboard::J) {
                    // Start game
                    selected_spaceship = 10;

                } else if (event.key.code == sf::Keyboard::K) {
                    // Start game
                    selected_spaceship = 11;

                } else if (event.key.code == sf::Keyboard::L) {
                    // Start game
                    selected_spaceship = 12;

                } else if (event.key.code == sf::Keyboard::M) {
                    // Start game
                    selected_spaceship = 13;

                } else if (event.key.code == sf::Keyboard::N) {
                    // Start game
                    selected_spaceship = 14;

                } else if (event.key.code == sf::Keyboard::O) {
                    // Start game
                    selected_spaceship = 15;

                } else if (event.key.code == sf::Keyboard::P) {
                    // Start game
                    selected_spaceship = 16;

                } else if (event.key.code == sf::Keyboard::Q) {
                    // Start game

                    selected_spaceship = 17;
                }

            }

        }

        window.clear();
        window.draw(background1);
        window.draw(sprite1);
        window.draw(sprite2);
        window.draw(sprite3);
        window.draw(sprite4);
        window.draw(sprite5);
        window.draw(sprite6);
        window.draw(sprite7);
        window.draw(sprite8);
        window.draw(sprite9);
        window.draw(sprite11);
        window.draw(sprite12);
        window.draw(sprite13);
        window.draw(sprite14);
        window.draw(sprite15);
        window.draw(sprite16);
        window.draw(sprite17);
        window.draw(sprite18);
        window.draw(Supership);
        window.draw(a_text);
        window.draw(b_text);
        window.draw(c_text);
        window.draw(d_text);
        window.draw(e_text);
        window.draw(f_text);
        window.draw(g_text);
        window.draw(h_text);
        window.draw(i_text);
        window.draw(j_text);
        window.draw(k_text);
        window.draw(l_text);
        window.draw(m_text);
        window.draw(n_text);
        window.draw(o_text);
        window.draw(p_text);
        window.draw(q_text);

        if (selected_spaceship != 0) {

            window.close();
            return selected_spaceship;

        }

        window.display();

    }
    display_menu();
    return 20;
}
void Game::getPlayerName(sf::RenderWindow & window) {
    sf::Font font;
    if (!font.loadFromFile("fonts/font1.otf")) { // Replace "arial.ttf" with the path to your font file
        std::cout << "Failed to load font!" << std::endl;
        return;
    }

    Texture bg_texture;
    bg_texture.loadFromFile("img/background_1.jpg");
    sf::Sprite background(bg_texture);
    sf::Text a_text("Select Ship", font, 80);

    a_text.setPosition(250, 550);
    sf::Text b_text("SPACE SHOOTER", font, 80);
    b_text.setFillColor(sf::Color::Red);
    b_text.setPosition(250, 100);

    sf::Text text;
    text.setFont(font);
    text.setCharacterSize(80);
    text.setFillColor(sf::Color::White);
    text.setPosition(200, 350);

    std::string playerName;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            } else if (event.type == sf::Event::TextEntered) {
                if (event.text.unicode == '\b' && !playerName.empty()) { // Handle backspace
                    playerName.pop_back();
                } else if (event.text.unicode < 128) { // Handle ASCII characters
                    playerName += static_cast < char > (event.text.unicode);
                }

            }
            text.setString("Player Name: " + playerName);

            if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2i mouse_position = sf::Mouse::getPosition(window);

                if (a_text.getGlobalBounds().contains(mouse_position.x, mouse_position.y)) {
                    // Restart game
                    //                if(playerName=="")
                    window.close();
                    start_game();

                }
            }

            if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::Enter) {
                    // Go back to main menu
                    //       if(playerName=="")
                    window.close();
                    start_game();

                }
            }
        }
        window.clear();

        window.draw(background);

        name = playerName;
        window.draw(text);
        window.draw(a_text);
        window.draw(b_text);
        window.display();
    }

}


void Game::add_score_to_file(int score, Player & p) {
    p.score = score;
    assignBadges();
    std::ofstream file("Highscores.txt", std::ios::app);
    file << p.name << "," << p.score << std::endl;
    file.close();

}

void Game::assignBadges() {
    std::ifstream file("Highscores.txt");
    Player players[100];

    int numPlayers = 0;
    std::string line;
    while (getline(file, line)) {
        Player player;
        size_t pos = line.find(',');
        player.name = line.substr(0, pos);
        line.erase(0, pos + 1);
        pos = line.find(',');

        player.score = std::stoi(line);
        players[numPlayers] = player;
        numPlayers++;
    }
    file.close();
    // Sort the players in descending order by score
    for (int i = 0; i < numPlayers - 1; i++) {
        for (int j = i + 1; j < numPlayers; j++) {
            if (players[i].score < players[j].score) {
                Player temp = players[i];
                players[i] = players[j];
                players[j] = temp;
            }
        }
    }
    // Assign badges to the top three players
    for (int i = 0; i < 3; i++) {
        if (i == 0) {
            players[i].badge = "Gold";
        } else if (i == 1) {
            players[i].badge = "Silver";
        } else {
            players[i].badge = "Bronze";
        }
    }
    // Update the scores file with the new badges
    std::ofstream outFile("Highscores.txt", std::ios::out);
    for (int i = 0; i < numPlayers; i++) {
        outFile << players[i].name << "," << players[i].score << std::endl;

    }
    outFile.close();
}

void Game::displayFileContent(const std::string & filename) {
    // Create SFML window
double scale=3;
    sf::RenderWindow window(sf::VideoMode(800, 900), "Highscores");
Texture goldtex;
goldtex.loadFromFile("img/PNG/Power-ups/shield_gold.png");
Sprite goldsprite(goldtex);
 goldsprite.setPosition(580, 350);

 goldsprite.setScale(scale, scale);


Texture silvertex;
silvertex.loadFromFile("img/PNG/Power-ups/shield_silver.png");
Sprite silversprite(silvertex);
 silversprite.setPosition(580, 460);

silversprite.setScale(scale, scale);

Texture bronzetex;
bronzetex.loadFromFile("img/PNG/Power-ups/shield_bronze.png");
Sprite bronzesprite(bronzetex);
bronzesprite.setPosition(580, 570);
bronzesprite.setScale(scale, scale);

    // Create font and text objects
    sf::Font font1, font;
    if (!font.loadFromFile("fonts/font1.otf")) {
        // Handle font loading error
        return;
    }
    if (!font1.loadFromFile("fonts/font.ttf")) {
        // Handle font loading error
        return;
    }
    Texture bg_texture;
    bg_texture.loadFromFile("img/background_1.jpg");
    sf::Sprite background(bg_texture);

    sf::Text text1, text2, text3;

    sf::Text Highscore("High Scores", font, 120);
    Highscore.setPosition(220, 80);
    Highscore.setFillColor(sf::Color::White);

    sf::Text players("Players", font, 60);
    players.setPosition(150, 250);
    players.setFillColor(sf::Color::White);

    sf::Text Intro("Space Shooter Game\n Programmed by Saffi Muhammad Hashir\n Reg# 22i-1293 ", font, 30);
    Intro.setPosition(300, 775);
    Intro.setFillColor(sf::Color::White);

    sf::Text return_menu("Main Menu", font, 60);
    return_menu.setPosition(350, 680);
    return_menu.setFillColor(sf::Color::White);

    text1.setFont(font1);
    text1.setCharacterSize(30);
    text1.setPosition(100, 350);
    text1.setFillColor(sf::Color::White);

    text2.setFont(font1);
    text2.setCharacterSize(30);
    text2.setPosition(100, 460);
    text2.setFillColor(sf::Color::White);

    text3.setFont(font1);
    text3.setCharacterSize(30);
    text3.setPosition(100, 570);
    text3.setFillColor(sf::Color::White);
    
    sf::Text gold("Gold", font, 25);
    gold.setPosition(180, 390);
    gold.setFillColor(sf::Color::White);
    
    sf::Text silver("Silver", font, 25);
    silver.setPosition(180, 500);
    silver.setFillColor(sf::Color::White);
    
    sf::Text bronze("Bronze", font, 25);
    bronze.setPosition(180, 610);
    bronze.setFillColor(sf::Color::White);

    // Open the file
    std::ifstream file(filename);
    if (!file.is_open()) {
        // Handle file opening error
        return;
    }

    // Read and display lines from the file
    std::string line1;
    std::getline(file, line1);
    text1.setString(std::to_string(1) + ".     Gold Medal: " + line1);
    std::string line2;
    std::getline(file, line2);
    text2.setString(std::to_string(2) + ".     Silver Medal: " + line2);
    std::string line3;
    std::getline(file, line3);
    text3.setString(std::to_string(3) + ".     Bronze Medal: " + line3);

    // Clear the window
    window.clear();
    window.draw(background);
    // Draw the text
    window.draw(Highscore);
    window.draw(Intro);
    window.draw(players);
    window.draw(return_menu);
window.draw(goldsprite);
window.draw(silversprite);
window.draw(bronzesprite);
window.draw(gold);
window.draw(silver);
window.draw(bronze);
    window.draw(text1);
    window.draw(text2);
    window.draw(text3);
    // Display the window
    window.display();

    // Wait for a short duration before displaying the next line

    // Close the file
    file.close();

    // Main event loop
    sf::Event event;
    while (window.isOpen()) {
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                // Close the window when the close button is clicked
                window.close();
            }
            if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2i mouse_position = sf::Mouse::getPosition(window);

                if (return_menu.getGlobalBounds().contains(mouse_position.x, mouse_position.y)) {
                    // Start game
                    window.close();
                    display_menu();

                }
            }
            if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::Enter) {
                    // Start game

                    window.close();
                    display_menu();
                }
            }
        }
    }
}

void Game::game_over_screen(RenderWindow & window, int score, int level, int wave) {
    window.close();

    RenderWindow start(VideoMode(780, 720), title);
    Texture bg_texture;

    bg_texture.loadFromFile("img/background.jpg");
    sf::Sprite background(bg_texture);

    sf::Font font;
    font.loadFromFile("fonts/font1.otf");
    PausemenuSound.play();

    while (start.isOpen()) {
        sf::Event event;
        while (start.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                start.close();
            }
        }
        sf::Text Over_text("GAME OVER !", font, 124);
        sf::Text resume_text("1. Main Menu", font, 54);
        sf::Text start_text("2. Restart Game", font, 54);
        sf::Text options_text("3. Options", font, 54);
        sf::Text exit_text("4. Exit", font, 54);
        Over_text.setPosition(200, 40);
        resume_text.setPosition(100, 210);
        start_text.setPosition(100, 310);
        options_text.setPosition(100, 410);
        exit_text.setPosition(100, 510);

        if (event.type == sf::Event::MouseButtonPressed) {
            sf::Vector2i mouse_position = sf::Mouse::getPosition(start);

            if (start_text.getGlobalBounds().contains(mouse_position.x, mouse_position.y)) {
                // Restart game
                start.close();
                PausemenuSound.stop();
                display_menu();
            }
            if (resume_text.getGlobalBounds().contains(mouse_position.x, mouse_position.y)) {
                // Go back to main menu
                start.close();
                PausemenuSound.stop();
                display_menu();
            } else if (options_text.getGlobalBounds().contains(mouse_position.x, mouse_position.y)) {
                // Go to spaceship selection screen
                start.close();
                displayFileContent("Highscores.txt");
            } else if (exit_text.getGlobalBounds().contains(mouse_position.x, mouse_position.y)) {
                // Exit game
                start.close();
            }
        }

        if (event.type == sf::Event::KeyPressed) {
            if (event.key.code == sf::Keyboard::Num1) {
                // Go back to main menu
                start.close();
                PausemenuSound.stop();
                display_menu();
            } else if (event.key.code == sf::Keyboard::Num2) {
                // Restart game
                start.close();
                PausemenuSound.stop();
                load_screen();
            } else if (event.key.code == sf::Keyboard::Num3) {
                // Go to spaceship selection screen
                displayFileContent("Highscores.txt");
            } else if (event.key.code == sf::Keyboard::Num4) {
                // Exit game
                start.close();
            } else if (event.key.code == sf::Keyboard::Escape) {
                // Pause game
                start.close();
            }
        }

        sf::Text score_text("Score: " + std::to_string(score), font, 50);
        score_text.setFillColor(Color::White);
        score_text.setPosition(500, 300);

        sf::Text level_text("Level: " + std::to_string(level), font, 50);
        level_text.setFillColor(Color::White);
        level_text.setPosition(500, 400);

        sf::Text wave_text("Wave: " + std::to_string(wave - 1), font, 50);
        wave_text.setFillColor(Color::White);
        wave_text.setPosition(500, 500);

        start.clear();
        start.draw(background);
        start.draw(Over_text);
        start.draw(resume_text);
        start.draw(start_text);
        start.draw(options_text);
        start.draw(exit_text);
        start.draw(score_text);
        start.draw(level_text);
        start.draw(wave_text);
        start.display();
    }
}


