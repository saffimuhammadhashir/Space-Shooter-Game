#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>


#include "Monster.h"


Monster::Monster() {
    texture.loadFromFile("img/monster.png");
    sprite.setTexture(texture);
    sprite.setScale(0.6, 0.6);
    x = 500;
    y = 50;
    speed = 200;
    speed1 = 200;
    active = false;
    beam_interval = 2;
    beam_duration = 10;
    move_interval = 2;

}

void Monster::activate() {
    active = true;
    sprite.setPosition(x, y);
    beam_timer.restart();
    move_timer.restart();
}
void Monster::deactivate() {
    active = false;
    StartFireMonster = NULL;
}
void Monster::newMonster(int a) {
    if (a == 0)
        texture.loadFromFile("img/monster.png");
    if (a == 1)
        texture.loadFromFile("img/monster1.png");

    state = a;
}
void Monster::update(float dt, Player & player) {
    if (!active) {
        return;
    }

    // move left and right
    if ((sprite.getPosition().x < -60 || sprite.getPosition().x > 800)) {
        move_timer.restart();
        speed = -speed;
    }
    if (sprite.getPosition().y < 0 || sprite.getPosition().y > 200) {
        move_timer.restart();
        speed1 = -speed1;
    }
    x += speed * dt;
    y += speed1 * dt;
    sprite.setPosition(x, y);

    // fire beam
    if (beam_timer.getElapsedTime().asSeconds() >= 6) {
        beam_timer.restart();
    } else if ((beam_timer.getElapsedTime().asSeconds() >= 4) || (beam_timer.getElapsedTime().asSeconds() >= 5)) {
        StartFireMonster = NULL;
        return;
    } else {
        MonsterFire * newFire = new MonsterFire();
        newFire -> activate(sprite.getPosition() + Vector2f(170, 340));
        newFire -> LinkFireMonster = StartFireMonster;
        StartFireMonster = newFire;

    }
    MonsterFire * current = StartFireMonster;
    while (current != NULL) {
        current -> update(dt);
        current = current -> LinkFireMonster;
    }
}
