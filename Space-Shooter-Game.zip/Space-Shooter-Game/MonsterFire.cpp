#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>

#include"MonsterFire.h"


MonsterFire::MonsterFire() {

    texture.loadFromFile("img/PNG/Lasers/laserBlue11.png");

    sprite.setTexture(texture);
    sprite.setScale(2, 2);
    firecheck = 0;
}

void MonsterFire::activate(Vector2f position) {
    active = true;
    visible = true;
    sprite.setPosition(position);

}

void MonsterFire::update(float time) {
    if (active) {

        sprite.move(0, 12);
        if (sprite.getPosition().y > 780) {
            active = false;
        }

    }
}
