#pragma once

#include <SFML/Graphics.hpp>

#include<iostream>

#include <SFML/Audio.hpp>

#include <time.h>

#include "DragonFire.h"


class Dragon {
    public: sf::Sprite sprite;
    sf::Texture texture;
    float x;
    float y;
    float speed,
    speed1;
    bool active;
    sf::Clock beam_timer;
    sf::Clock move_timer;
    float beam_interval;
    float move_interval;
    float beam_duration;
    DragonFire * StartFireDragon = NULL;
    int state;
    Dragon();
    void activate();
    void deactivate();
    void newDragon(int a);
    void update(float dt, Player & player);
};
